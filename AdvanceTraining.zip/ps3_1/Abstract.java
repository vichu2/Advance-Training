package com.corejava.ps3_1;
public abstract class Abstract
{
public abstract void Play();
}