package com.corejava.ps6_3;

import java.util.Comparator;

public class EmpComparator implements Comparator<Employee> {

    @Override
    public int compare(Employee object1, Employee object2) {
        return object1.getname().compareTo(object2.getname());
    }
}