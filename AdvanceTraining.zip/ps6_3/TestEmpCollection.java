package com.corejava.ps6_3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class TestEmpCollection {
    public static void main(String[] args) {

        List<Employee> list=new ArrayList<Employee>();

        list.add(new Employee(33186,"Dhoni",37));
        list.add(new Employee(33187,"Raina",31));
        list.add(new Employee(33188,"Kaif",45));
        list.add(new Employee(33189,"Yuvraj",38));

        Collections.sort(list,new EmpComparator());

        for(int i=0;i<list.size();i++) {

            System.out.print("age:"+list.get(i).getAge());
            System.out.print("empid:"+list.get(i).getEmpid());
            System.out.println("name:"+list.get(i).getname());
        }

        ListIterator<Employee> itr= list.listIterator();

        while(itr.hasNext())
        {
        	Employee emp = itr.next();
            System.out.println(emp.getname()+","+emp.getAge()+","+emp.getEmpid());
        }
        while (itr.hasPrevious())
        {
        	Employee emp = itr.previous();
            System.out.println(emp.getname()+","+emp.getAge()+","+emp.getEmpid());
        }
    }
}